// Mock data for the Trust Middleware prototype.
// 100 merchants with trust scores, history, connections, and fraud flags.

export type Merchant = {
  id: string;
  name: string;
  businessType: string;
  address: string;
  trustScore: number;
  trustDelta: number; // weekly change
  fraudFlag: null | { severity: "low" | "high"; reason: string };
  history: { date: string; score: number }[];
  connections: string[]; // merchant ids
};

const FIRST = [
  "Sagar", "Anish", "Bibek", "Pratik", "Sushma", "Kabita", "Niraj", "Aarati",
  "Rajesh", "Manisha", "Dipesh", "Prerana", "Roshan", "Sunita", "Krishna",
  "Sabin", "Asmita", "Ramesh", "Nabin", "Sneha",
];
const LAST = [
  "Shrestha", "Tamang", "Karki", "Gurung", "Maharjan", "Bhattarai", "Adhikari",
  "Thapa", "Rai", "Limbu", "Pandey", "Khadka", "Magar", "Acharya", "Sharma",
];
const BIZ = [
  "Grocery Store", "Tea Shop", "Mobile Repair", "Tailoring", "Bakery",
  "Electronics", "Pharmacy", "Restaurant", "Bookstore", "Hardware",
  "Beauty Parlor", "Print Shop", "Pasal", "Boutique", "Cyber Cafe",
];
const AREAS = [
  "Thamel, Kathmandu", "Pulchowk, Lalitpur", "Bhaktapur Durbar Sq.",
  "Lakeside, Pokhara", "Birgunj Main Rd.", "Biratnagar Bazar",
  "Itahari Junction", "Butwal Traffic Chowk", "Dharan Bhanu Chowk",
  "New Road, Kathmandu", "Patan Dhoka", "Maharajgunj",
];

// Deterministic PRNG so the data is stable across renders.
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(42);
const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)];

function genHistory(end: number): { date: string; score: number }[] {
  const points: { date: string; score: number }[] = [];
  let s = end - (rand() * 30 - 5);
  const now = new Date();
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now);
    d.setMonth(d.getMonth() - i);
    s += (end - s) * 0.18 + (rand() * 8 - 4);
    points.push({
      date: d.toLocaleDateString("en", { month: "short" }),
      score: Math.max(20, Math.min(95, Math.round(s))),
    });
  }
  points[points.length - 1].score = end;
  return points;
}

export const merchants: Merchant[] = Array.from({ length: 100 }, (_, i) => {
  const id = `M${String(1001 + i).padStart(4, "0")}`;
  const score = Math.round(35 + rand() * 60);
  const delta = Math.round((rand() * 16 - 7) * 10) / 10;
  // ~8% have fraud flags
  const flag =
    rand() < 0.08
      ? {
          severity: rand() < 0.4 ? ("high" as const) : ("low" as const),
          reason: pick([
            "Suspicious endorsement ring detected",
            "Rapid score boost from single cluster",
            "Reciprocal endorsements with low-trust nodes",
            "Unusual transaction velocity",
          ]),
        }
      : null;
  return {
    id,
    name: `${pick(FIRST)} ${pick(LAST)}`,
    businessType: pick(BIZ),
    address: pick(AREAS),
    trustScore: score,
    trustDelta: delta,
    fraudFlag: flag,
    history: genHistory(score),
    connections: [],
  };
});

// Build connections — small-world: each merchant connects to 3-8 others.
const rand2 = mulberry32(99);
merchants.forEach((m, i) => {
  const n = 3 + Math.floor(rand2() * 6);
  const set = new Set<string>();
  while (set.size < n) {
    const j = Math.floor(rand2() * merchants.length);
    if (j !== i) set.add(merchants[j].id);
  }
  m.connections = Array.from(set);
});

// Make sure connections are reciprocal for a few clusters
merchants.forEach((m) => {
  m.connections.forEach((cid) => {
    const other = merchants.find((x) => x.id === cid);
    if (other && !other.connections.includes(m.id) && rand2() < 0.5) {
      other.connections.push(m.id);
    }
  });
});

export const stats = {
  total: merchants.length,
  average: Math.round(
    merchants.reduce((s, m) => s + m.trustScore, 0) / merchants.length
  ),
  fraudCount: merchants.filter((m) => m.fraudFlag).length,
};

// "Logged in" merchant for the user view (first non-flagged one).
export const currentMerchant = merchants.find((m) => !m.fraudFlag) ?? merchants[0];

export type ConnectionDetail = {
  id: string;
  type: "endorser" | "endorsee" | "transaction";
  durationMonths: number;
  transactions: number;
};

export function getConnectionDetails(m: Merchant): ConnectionDetail[] {
  const r = mulberry32(parseInt(m.id.slice(1)));
  return m.connections.map((cid) => {
    const t = r();
    const type: ConnectionDetail["type"] =
      t < 0.33 ? "endorser" : t < 0.66 ? "endorsee" : "transaction";
    return {
      id: cid,
      type,
      durationMonths: 1 + Math.floor(r() * 36),
      transactions: Math.floor(r() * 80),
    };
  });
}

export function trustLabel(score: number) {
  if (score >= 80) return { label: "Excellent", color: "text-success" };
  if (score >= 65) return { label: "Strong", color: "text-success" };
  if (score >= 50) return { label: "Building", color: "text-warning" };
  if (score >= 35) return { label: "Developing", color: "text-warning" };
  return { label: "Needs work", color: "text-destructive" };
}
