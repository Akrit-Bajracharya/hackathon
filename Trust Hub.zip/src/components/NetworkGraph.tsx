import { useMemo, useRef, useState } from "react";
import type { Merchant } from "@/lib/mockData";
import { merchants as ALL } from "@/lib/mockData";

type Node = { id: string; x: number; y: number; vx: number; vy: number; r: number; flagged: boolean; cluster: number; isCenter?: boolean };
type Edge = { source: string; target: string; type?: "endorse" | "transaction" | "both"; weight?: number };

type Props = {
  centerId?: string;
  merchantIds?: string[];
  edges?: Edge[];
  height?: number;
  onNodeClick?: (id: string) => void;
};

// Simple deterministic force-directed layout (a few iterations).
function layout(nodes: Node[], edges: Edge[], width: number, height: number) {
  const cx = width / 2;
  const cy = height / 2;
  for (let iter = 0; iter < 220; iter++) {
    // Repulsion
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i], b = nodes[j];
        const dx = a.x - b.x, dy = a.y - b.y;
        const d2 = dx * dx + dy * dy + 0.01;
        const force = 1200 / d2;
        const fx = dx * force, fy = dy * force;
        if (!a.isCenter) { a.vx += fx; a.vy += fy; }
        if (!b.isCenter) { b.vx -= fx; b.vy -= fy; }
      }
    }
    // Attraction
    edges.forEach((e) => {
      const a = nodes.find((n) => n.id === e.source);
      const b = nodes.find((n) => n.id === e.target);
      if (!a || !b) return;
      const dx = b.x - a.x, dy = b.y - a.y;
      const d = Math.sqrt(dx * dx + dy * dy) + 0.01;
      const force = (d - 90) * 0.04;
      const fx = (dx / d) * force, fy = (dy / d) * force;
      if (!a.isCenter) { a.vx += fx; a.vy += fy; }
      if (!b.isCenter) { b.vx -= fx; b.vy -= fy; }
    });
    // Center gravity
    nodes.forEach((n) => {
      if (n.isCenter) { n.x = cx; n.y = cy; n.vx = 0; n.vy = 0; return; }
      n.vx += (cx - n.x) * 0.01;
      n.vy += (cy - n.y) * 0.01;
      n.vx *= 0.82; n.vy *= 0.82;
      n.x += n.vx; n.y += n.vy;
      n.x = Math.max(n.r + 4, Math.min(width - n.r - 4, n.x));
      n.y = Math.max(n.r + 4, Math.min(height - n.r - 4, n.y));
    });
  }
}

export function NetworkGraph({ centerId, merchantIds, edges: edgesIn, height = 480, onNodeClick }: Props) {
  const width = 760;
  const [zoom, setZoom] = useState(1);
  const [hover, setHover] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const { nodes, edges, byId } = useMemo(() => {
    const ids = new Set<string>(merchantIds ?? []);
    if (centerId) ids.add(centerId);
    const subset = ALL.filter((m) => ids.has(m.id));
    const byId = new Map(subset.map((m) => [m.id, m]));

    // Build edges if not provided: connections among subset
    let edges: Edge[] = edgesIn ?? [];
    if (!edgesIn) {
      const seen = new Set<string>();
      subset.forEach((m) => {
        m.connections.forEach((c) => {
          if (!byId.has(c)) return;
          const key = [m.id, c].sort().join("-");
          if (seen.has(key)) return;
          seen.add(key);
          edges.push({ source: m.id, target: c });
        });
      });
    }

    // Detect fraud clusters: cluster id by flagged group
    const cluster = new Map<string, number>();
    let cid = 0;
    subset.forEach((m) => {
      if (cluster.has(m.id)) return;
      cluster.set(m.id, ++cid);
      const stack = [m.id];
      while (stack.length) {
        const cur = stack.pop()!;
        const me = byId.get(cur)!;
        me.connections.forEach((c) => {
          if (byId.has(c) && !cluster.has(c)) {
            cluster.set(c, cid);
            stack.push(c);
          }
        });
      }
    });

    const nodes: Node[] = subset.map((m, i) => {
      const angle = (i / subset.length) * Math.PI * 2;
      const isCenter = m.id === centerId;
      return {
        id: m.id,
        x: width / 2 + Math.cos(angle) * (isCenter ? 0 : 180),
        y: height / 2 + Math.sin(angle) * (isCenter ? 0 : 140),
        vx: 0, vy: 0,
        r: isCenter ? 22 : 12 + Math.min(8, m.connections.length),
        flagged: !!m.fraudFlag,
        cluster: cluster.get(m.id) ?? 0,
        isCenter,
      };
    });

    layout(nodes, edges, width, height);
    return { nodes, edges, byId };
  }, [centerId, merchantIds, edgesIn, height]);

  function colorFor(n: Node) {
    if (n.isCenter) return "var(--primary)";
    if (n.flagged) return "var(--destructive)";
    // Check if any neighbor in same cluster is flagged
    const flaggedCluster = nodes.some((x) => x.cluster === n.cluster && x.flagged);
    if (flaggedCluster) return "oklch(0.7 0.18 30)";
    return "var(--success)";
  }

  function edgeColor(e: Edge) {
    if (e.type === "both") return "var(--success)";
    if (e.type === "transaction") return "oklch(0.75 0.15 75)";
    if (e.type === "endorse") return "oklch(0.6 0.14 240)";
    const a = nodes.find((n) => n.id === e.source);
    const b = nodes.find((n) => n.id === e.target);
    if (a?.flagged && b?.flagged) return "var(--destructive)";
    return "var(--border)";
  }

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-border bg-card">
      <div className="absolute right-3 top-3 z-10 flex gap-1 rounded-lg border border-border bg-background/80 p-1 backdrop-blur">
        <button onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))} className="h-7 w-7 rounded text-sm hover:bg-muted">+</button>
        <button onClick={() => setZoom((z) => Math.max(0.5, z - 0.2))} className="h-7 w-7 rounded text-sm hover:bg-muted">−</button>
        <button onClick={() => setZoom(1)} className="h-7 rounded px-2 text-xs hover:bg-muted">reset</button>
      </div>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${width} ${height}`}
        className="block w-full"
        style={{ height }}
      >
        <g style={{ transform: `scale(${zoom})`, transformOrigin: "center" }}>
          {edges.map((e, i) => {
            const a = nodes.find((n) => n.id === e.source);
            const b = nodes.find((n) => n.id === e.target);
            if (!a || !b) return null;
            const w = Math.max(1, Math.min(6, (e.weight ?? 1)));
            return (
              <line
                key={i}
                x1={a.x} y1={a.y} x2={b.x} y2={b.y}
                stroke={edgeColor(e)}
                strokeWidth={w}
                strokeOpacity={hover && hover !== a.id && hover !== b.id ? 0.15 : 0.55}
              />
            );
          })}
          {nodes.map((n) => {
            const m = byId.get(n.id)!;
            const isHover = hover === n.id;
            return (
              <g
                key={n.id}
                transform={`translate(${n.x},${n.y})`}
                className="cursor-pointer"
                onMouseEnter={() => setHover(n.id)}
                onMouseLeave={() => setHover(null)}
                onClick={() => onNodeClick?.(n.id)}
              >
                <circle
                  r={n.r + (isHover ? 4 : 0)}
                  fill={colorFor(n)}
                  fillOpacity={n.isCenter ? 1 : 0.85}
                  stroke={n.isCenter ? "var(--primary)" : "white"}
                  strokeWidth={n.isCenter ? 3 : 1.5}
                />
                {(isHover || n.isCenter) && (
                  <g>
                    <rect x={n.r + 6} y={-12} rx={6} height={24}
                      width={Math.max(80, m.name.length * 7)}
                      fill="var(--popover)" stroke="var(--border)" />
                    <text x={n.r + 14} y={4} fontSize={11} fill="var(--foreground)">
                      {m.name} · {m.trustScore}
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </g>
      </svg>
      <div className="flex flex-wrap items-center gap-3 border-t border-border bg-muted/40 px-4 py-2 text-xs text-muted-foreground">
        <Legend color="var(--primary)" label="You" />
        <Legend color="var(--success)" label="Healthy" />
        <Legend color="var(--destructive)" label="Flagged ring" />
        <span className="ml-auto">Hover a node · Click to focus</span>
      </div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}
