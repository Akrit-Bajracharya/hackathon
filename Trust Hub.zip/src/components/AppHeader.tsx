import { Link } from "@tanstack/react-router";
import { useRouterState } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";

const links = [
  { to: "/merchant", label: "My Profile" },
  { to: "/social", label: "Network" },
  { to: "/psychometric", label: "Quiz" },
  { to: "/admin", label: "Admin" },
];

export function AppHeader() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  if (path === "/" || path === "/login") return null;
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2 font-semibold">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <span className="text-base tracking-tight">Saakshi</span>
          <span className="hidden text-xs font-normal text-muted-foreground md:inline">
            Trust Middleware
          </span>
        </Link>
        <nav className="flex items-center gap-1">
          {links.map((l) => {
            const active = path.startsWith(l.to);
            return (
              <Link
                key={l.to}
                to={l.to}
                className={
                  "rounded-lg px-3 py-1.5 text-sm transition-colors " +
                  (active
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-muted-foreground hover:text-foreground")
                }
              >
                {l.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
