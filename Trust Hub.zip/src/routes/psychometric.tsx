import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ArrowRight, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/psychometric")({
  component: Quiz,
});

// Questions designed so honest answers reveal financial psychology
// without telegraphing the "correct" answer.
const QUESTIONS = [
  {
    q: "When an unexpected payment is delayed by a customer, you usually…",
    a: [
      "Wait a few days, then follow up politely",
      "Send a reminder the same day",
      "Adjust my own plans to absorb the gap",
      "Borrow short-term to cover commitments",
    ],
  },
  {
    q: "Imagine an extra Rs. 10,000 lands in your account today. First thought?",
    a: [
      "Reinvest in stock or supplies",
      "Save it for an emergency",
      "Pay down something I owe",
      "Treat myself or family",
    ],
  },
  {
    q: "You track your daily sales by…",
    a: [
      "A notebook or ledger",
      "An app on my phone",
      "Memory — I just know",
      "I don't really track day-to-day",
    ],
  },
  {
    q: "How often do you compare this month's earnings to last month's?",
    a: ["Every month", "Sometimes", "Rarely", "Never thought about it"],
  },
  {
    q: "When a supplier offers a discount for paying in advance, you…",
    a: [
      "Always take it if cashflow allows",
      "Take it occasionally",
      "Prefer to pay on the usual schedule",
      "Avoid prepaying"
    ],
  },
  {
    q: "Your biggest worry about your business is…",
    a: [
      "Inconsistent customers",
      "Rising costs",
      "Competition",
      "Running out of cash",
    ],
  },
  {
    q: "If a friend asked to borrow money from you, you would…",
    a: [
      "Lend only what I can spare and forget about",
      "Lend with clear repayment terms",
      "Politely decline",
      "It depends on the friend",
    ],
  },
  {
    q: "How do you set prices?",
    a: [
      "Cost plus a fixed margin",
      "Match competitors",
      "What customers seem willing to pay",
      "Gut feeling",
    ],
  },
  {
    q: "A risky opportunity could double your income — or you could lose 30%. You…",
    a: ["Go for it", "Try a small version first", "Wait to see others try it", "Skip it"],
  },
  {
    q: "On a typical week, you check your business numbers…",
    a: ["Daily", "Two or three times", "Once", "Almost never"],
  },
  {
    q: "When demand spikes, you prefer to…",
    a: [
      "Hire help quickly",
      "Work longer hours myself",
      "Raise prices a bit",
      "Cap orders to keep quality",
    ],
  },
  {
    q: "Your goal for the next 12 months is closest to…",
    a: [
      "Grow steadily and stay stable",
      "Expand aggressively",
      "Keep things as they are",
      "Pay down debts and simplify",
    ],
  },
];

function Quiz() {
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [done, setDone] = useState(false);

  const total = QUESTIONS.length;
  const progress = ((done ? total : idx) / total) * 100;

  const select = (ai: number) => {
    const next = [...answers];
    next[idx] = ai;
    setAnswers(next);
    if (idx + 1 >= total) setDone(true);
    else setIdx(idx + 1);
  };

  const back = () => {
    if (done) { setDone(false); return; }
    if (idx > 0) setIdx(idx - 1);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-xl px-6 py-20 text-center">
        <div className="mx-auto mb-6 grid h-20 w-20 place-items-center rounded-full bg-success/10 text-success">
          <CheckCircle2 className="h-10 w-10" />
        </div>
        <h1 className="text-3xl font-bold">Quiz complete!</h1>
        <p className="mt-3 text-muted-foreground">
          Thank you. Your responses have been recorded.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <button
            onClick={() => { setDone(false); setIdx(0); setAnswers([]); }}
            className="rounded-lg border border-input px-4 py-2 text-sm hover:bg-muted"
          >
            Retake
          </button>
          <Link to="/merchant" className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            Back to profile
          </Link>
        </div>
      </div>
    );
  }

  const q = QUESTIONS[idx];
  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <div className="mb-3 flex items-center justify-between text-xs text-muted-foreground">
        <span>Question {idx + 1} of {total}</span>
        <span>Plain answers · no scoring shown</span>
      </div>
      <div className="mb-6 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} />
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm md:p-8">
        <h2 className="text-xl font-semibold leading-snug md:text-2xl">{q.q}</h2>
        <div className="mt-6 space-y-2.5">
          {q.a.map((opt, i) => {
            const chosen = answers[idx] === i;
            return (
              <button
                key={i}
                onClick={() => select(i)}
                className={
                  "w-full rounded-xl border px-4 py-3 text-left text-sm transition " +
                  (chosen
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/40 hover:bg-muted/40")
                }
              >
                {opt}
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-5 flex items-center justify-between">
        <button
          onClick={back}
          disabled={idx === 0}
          className="inline-flex items-center gap-1.5 rounded-lg border border-input px-3 py-2 text-sm disabled:opacity-40 hover:bg-muted"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <span className="text-xs text-muted-foreground">
          Tap an answer to continue
          <ArrowRight className="ml-1 inline h-3.5 w-3.5" />
        </span>
      </div>
    </div>
  );
}
