import { createFileRoute, Link } from "@tanstack/react-router";
import { currentMerchant, trustLabel } from "@/lib/mockData";
import { TrustChart } from "@/components/TrustChart";
import { CheckCircle2, AlertCircle, ArrowUpRight, ArrowDownRight, Network } from "lucide-react";

export const Route = createFileRoute("/merchant")({
  component: MerchantProfile,
});

function MerchantProfile() {
  const m = currentMerchant;
  const t = trustLabel(m.trustScore);
  const rising = m.trustDelta >= 0;

  // Plain-language meaning
  const meaning = rising
    ? "You're trending up. Lenders see consistent, positive activity."
    : "Your score is dipping. A few small steps below can turn it around.";

  // Positive vs improvement signals (mocked from score)
  const positives = [
    "Regular transactions with established merchants",
    "Reliable repayment history",
    "Multiple endorsements over time",
  ];
  const improvements = rising
    ? ["Diversify your endorser network beyond your immediate cluster"]
    : [
        "Increase transaction frequency with verified merchants",
        "Reach out for endorsements from long-standing partners",
        "Maintain consistent on-time payments for 30 days",
      ];

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-wide text-muted-foreground">
              Merchant Profile
            </div>
            <h1 className="mt-1 text-2xl font-bold">{m.name}</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {m.id} · {m.businessType} · {m.address}
            </p>
          </div>
          <Link
            to="/social"
            className="inline-flex items-center gap-1.5 rounded-lg border border-input px-3 py-2 text-sm hover:bg-muted"
          >
            <Network className="h-4 w-4" /> View connections
          </Link>
        </div>

        <div className="my-8 text-center">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">
            Your trust score
          </div>
          <div className="my-2 inline-flex items-baseline gap-3">
            <span className="bg-gradient-to-br from-primary to-success bg-clip-text text-7xl font-extrabold tracking-tight text-transparent md:text-8xl">
              {m.trustScore}
            </span>
            <span className="text-2xl text-muted-foreground">/100</span>
          </div>
          <div className={"text-lg font-medium " + t.color}>{t.label}</div>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            {meaning}
          </p>
        </div>

        <div className="rounded-xl border border-border p-4">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-semibold">Trust trajectory</h2>
            <span
              className={
                "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium " +
                (rising ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive")
              }
            >
              {rising ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
              {rising ? "Rising" : "Declining"} {Math.abs(m.trustDelta).toFixed(1)} pts/week
            </span>
          </div>
          <TrustChart data={m.history} delta={m.trustDelta} />
          <p className="mt-3 text-xs text-muted-foreground">
            If you keep going at this pace, expect a score around{" "}
            <strong className="text-foreground">
              {Math.max(0, Math.min(100, Math.round(m.trustScore + m.trustDelta * 4)))}
            </strong>{" "}
            in about a month.
          </p>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <SignalList
            title="What's working"
            items={positives}
            tone="positive"
          />
          <SignalList
            title="Where to focus"
            items={improvements}
            tone="negative"
          />
        </div>
      </div>
    </div>
  );
}

function SignalList({
  title,
  items,
  tone,
}: {
  title: string;
  items: string[];
  tone: "positive" | "negative";
}) {
  const positive = tone === "positive";
  return (
    <div
      className={
        "rounded-xl border p-4 " +
        (positive ? "border-success/30 bg-success/5" : "border-destructive/30 bg-destructive/5")
      }
    >
      <h3 className={"mb-3 text-sm font-semibold " + (positive ? "text-success" : "text-destructive")}>
        {title}
      </h3>
      <ul className="space-y-2">
        {items.map((it) => (
          <li key={it} className="flex items-start gap-2 text-sm">
            {positive ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" />
            ) : (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            )}
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
