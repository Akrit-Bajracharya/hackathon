import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, User, Lock, ArrowRight, Network, Activity, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2 font-semibold">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <span className="text-lg tracking-tight">Saakshi</span>
        </div>
        <Link to="/admin" className="text-sm text-muted-foreground hover:text-foreground">
          Demo dashboard →
        </Link>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-24 pt-12">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Prototype demo
          </span>
          <h1 className="mx-auto mt-5 max-w-3xl text-balance text-5xl font-extrabold tracking-tight md:text-6xl">
            Trust middleware for{" "}
            <span className="bg-gradient-to-r from-primary to-success bg-clip-text text-transparent">
              merchant lending
            </span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-balance text-muted-foreground">
            A unified trust score from behavior, psychometrics, and social signals — so
            lenders can see who to back, and merchants can grow on merit.
          </p>
        </div>

        <div className="mx-auto mt-14 grid max-w-3xl gap-4 md:grid-cols-2">
          <Link
            to="/login"
            search={{ role: "user" }}
            className="group rounded-2xl border border-border bg-card p-6 shadow-sm transition hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md"
          >
            <div className="mb-4 grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary">
              <User className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold">I'm a merchant</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              View your trust score, social network, and ways to improve.
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
              Continue <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </span>
          </Link>

          <Link
            to="/login"
            search={{ role: "admin" }}
            className="group rounded-2xl border border-border bg-card p-6 shadow-sm transition hover:-translate-y-0.5 hover:border-primary/50 hover:shadow-md"
          >
            <div className="mb-4 grid h-12 w-12 place-items-center rounded-xl bg-success/10 text-success">
              <Lock className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold">I'm an admin</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Full dashboard — merchant table, fraud rings, audit trail.
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-success">
              Continue <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
            </span>
          </Link>
        </div>

        <div className="mx-auto mt-20 grid max-w-4xl gap-4 md:grid-cols-3">
          <Feature icon={Activity} title="Trust trajectory" desc="See score change over time, weekly." />
          <Feature icon={Network} title="Social graph" desc="Endorsements & transactions visualised." />
          <Feature icon={AlertTriangle} title="Fraud rings" desc="Auto-detect reciprocal boosting." />
        </div>
      </main>
    </div>
  );
}

function Feature({ icon: Icon, title, desc }: { icon: typeof Activity; title: string; desc: string }) {
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4">
      <Icon className="h-5 w-5 text-primary" />
      <div className="mt-2 text-sm font-semibold">{title}</div>
      <div className="text-xs text-muted-foreground">{desc}</div>
    </div>
  );
}
