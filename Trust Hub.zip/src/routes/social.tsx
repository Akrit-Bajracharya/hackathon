import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { currentMerchant, merchants, getConnectionDetails, type ConnectionDetail } from "@/lib/mockData";
import { NetworkGraph } from "@/components/NetworkGraph";
import { Handshake, Repeat, Star, Plus, Check } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/social")({
  component: SocialPage,
});

type FilterKey = "all" | "endorser" | "endorsee" | "transaction";

function SocialPage() {
  const me = currentMerchant;
  const details = useMemo(() => getConnectionDetails(me), [me]);
  const [filter, setFilter] = useState<FilterKey>("all");
  const [active, setActive] = useState<string | null>(details[0]?.id ?? null);
  const [endorsed, setEndorsed] = useState<Set<string>>(new Set());

  const visible = details.filter((d) => filter === "all" || d.type === filter);
  const visibleIds = visible.map((d) => d.id);

  // Edges with semantic type
  const edges = useMemo(() => {
    return details.map((d) => ({
      source: me.id,
      target: d.id,
      type: (d.type === "transaction"
        ? "transaction"
        : "endorse") as "transaction" | "endorse",
      weight: Math.max(1, Math.min(6, Math.round(d.transactions / 12))),
    }));
  }, [details, me.id]);

  const activeDetail = visible.find((d) => d.id === active) ?? visible[0];
  const activeMerchant = merchants.find((m) => m.id === activeDetail?.id);

  const handleEndorse = (id: string) => {
    if (endorsed.has(id)) return;
    setEndorsed(new Set([...endorsed, id]));
    const name = merchants.find((m) => m.id === id)?.name ?? "merchant";
    toast.success(`You endorsed ${name}.`);
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Your business network</h1>
        <p className="text-sm text-muted-foreground">
          See who endorses you, who you endorse, and who you transact with.
        </p>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        <FilterChip current={filter} val="all" onClick={setFilter}>All</FilterChip>
        <FilterChip current={filter} val="endorser" onClick={setFilter}>Endorsers</FilterChip>
        <FilterChip current={filter} val="endorsee" onClick={setFilter}>Endorsed by you</FilterChip>
        <FilterChip current={filter} val="transaction" onClick={setFilter}>Transacted with</FilterChip>
      </div>

      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <aside className="rounded-2xl border border-border bg-card">
          <div className="border-b border-border p-4">
            <h2 className="text-sm font-semibold">Connections</h2>
            <p className="text-xs text-muted-foreground">{visible.length} merchants</p>
          </div>
          <ul className="max-h-[640px] overflow-y-auto">
            {visible.map((d) => {
              const m = merchants.find((x) => x.id === d.id)!;
              const isActive = d.id === active;
              return (
                <li key={d.id}>
                  <button
                    onClick={() => setActive(d.id)}
                    className={
                      "flex w-full items-center gap-3 border-b border-border/60 px-4 py-3 text-left transition " +
                      (isActive ? "bg-primary/5" : "hover:bg-muted/40")
                    }
                  >
                    <Avatar name={m.name} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{m.name}</div>
                      <div className="text-xs capitalize text-muted-foreground">
                        {d.type} · {d.transactions} txns
                      </div>
                    </div>
                  </button>
                </li>
              );
            })}
            {visible.length === 0 && (
              <li className="p-6 text-center text-sm text-muted-foreground">
                No connections of this type.
              </li>
            )}
          </ul>
        </aside>

        <div className="space-y-4">
          <NetworkGraph
            centerId={me.id}
            merchantIds={[me.id, ...visibleIds]}
            edges={edges.filter((e) => visibleIds.includes(e.target))}
            height={460}
            onNodeClick={(id) => id !== me.id && setActive(id)}
          />
          <div className="flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card px-4 py-2.5 text-xs text-muted-foreground">
            <LegendDot color="oklch(0.6 0.14 240)" label="Endorsement" />
            <LegendDot color="oklch(0.75 0.15 75)" label="Transaction" />
            <LegendDot color="var(--success)" label="Both" />
            <span className="ml-auto">Edge thickness = relationship strength</span>
          </div>

          {activeDetail && activeMerchant && (
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Avatar name={activeMerchant.name} size={48} />
                  <div>
                    <div className="text-lg font-semibold">{activeMerchant.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {activeMerchant.id} · {activeMerchant.businessType}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleEndorse(activeMerchant.id)}
                  disabled={endorsed.has(activeMerchant.id)}
                  className={
                    "inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition " +
                    (endorsed.has(activeMerchant.id)
                      ? "bg-success/10 text-success"
                      : "bg-primary text-primary-foreground hover:opacity-90")
                  }
                >
                  {endorsed.has(activeMerchant.id) ? (
                    <><Check className="h-4 w-4" /> Endorsed</>
                  ) : (
                    <><Plus className="h-4 w-4" /> Endorse merchant</>
                  )}
                </button>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                <Stat icon={Star} label="Relationship" value={cap(activeDetail.type)} />
                <Stat icon={Handshake} label="Duration" value={`${activeDetail.durationMonths} months`} />
                <Stat icon={Repeat} label="Transactions" value={activeDetail.transactions.toString()} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function cap(s: string) { return s[0].toUpperCase() + s.slice(1); }

function FilterChip({ current, val, onClick, children }: any) {
  const active = current === val;
  return (
    <button
      onClick={() => onClick(val)}
      className={
        "rounded-full border px-3.5 py-1.5 text-sm transition " +
        (active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-card hover:border-primary/40")
      }
    >
      {children}
    </button>
  );
}

function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const initials = name.split(" ").map((p) => p[0]).slice(0, 2).join("");
  return (
    <span
      className="grid shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary/80 to-success/80 text-xs font-semibold text-primary-foreground"
      style={{ width: size, height: size, fontSize: size * 0.36 }}
    >
      {initials}
    </span>
  );
}

function Stat({ icon: Icon, label, value }: any) {
  return (
    <div className="rounded-xl border border-border p-3">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <div className="mt-1 text-base font-semibold">{value}</div>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}
