import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { ShieldCheck, Lock } from "lucide-react";

const searchSchema = z.object({
  role: z.enum(["user", "admin"]).optional().default("user"),
});

export const Route = createFileRoute("/login")({
  validateSearch: searchSchema,
  component: Login,
});

function Login() {
  const { role } = Route.useSearch();
  const navigate = useNavigate();
  const [email, setEmail] = useState(role === "admin" ? "admin@saakshi.np" : "merchant@saakshi.np");
  const [password, setPassword] = useState(role === "admin" ? "admin123" : "demo");
  const [err, setErr] = useState("");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    // Admin recognised only by these credentials
    const isAdmin = email === "admin@saakshi.np" && password === "admin123";
    if (role === "admin" && !isAdmin) {
      setErr("Admin credentials invalid.");
      return;
    }
    if (isAdmin) navigate({ to: "/admin" });
    else navigate({ to: "/merchant" });
  };

  return (
    <div className="grid min-h-screen place-items-center px-6 py-12">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2 font-semibold">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground">
            <ShieldCheck className="h-5 w-5" />
          </span>
          Saakshi
        </Link>
        <div className="rounded-2xl border border-border bg-card p-8 shadow-sm">
          <div className="mb-6 flex items-center gap-2">
            {role === "admin" ? (
              <Lock className="h-5 w-5 text-success" />
            ) : (
              <ShieldCheck className="h-5 w-5 text-primary" />
            )}
            <h1 className="text-xl font-semibold">
              {role === "admin" ? "Admin sign in" : "Merchant sign in"}
            </h1>
          </div>
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Email</label>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-muted-foreground">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
            </div>
            {err && <p className="text-sm text-destructive">{err}</p>}
            <button
              type="submit"
              className="w-full rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90"
            >
              Continue
            </button>
          </form>
          <div className="mt-6 rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
            <strong>Demo:</strong> Admin uses{" "}
            <code className="rounded bg-background px-1">admin@saakshi.np / admin123</code>. Any
            other credentials sign in as a merchant.
          </div>
        </div>
      </div>
    </div>
  );
}
