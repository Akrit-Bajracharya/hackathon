import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { merchants, stats, trustLabel, type Merchant } from "@/lib/mockData";
import { TrustChart } from "@/components/TrustChart";
import { NetworkGraph } from "@/components/NetworkGraph";
import {
  Users, TrendingUp, AlertTriangle, Search, ArrowUpDown,
  ArrowUp, ArrowDown, ChevronLeft, ChevronRight, X,
} from "lucide-react";

export const Route = createFileRoute("/admin")({
  component: AdminDashboard,
});

const PAGE_SIZE = 10;

function AdminDashboard() {
  const [query, setQuery] = useState("");
  const [sortDir, setSortDir] = useState<"desc" | "asc">("desc");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Merchant | null>(null);

  const filtered = useMemo(() => {
    let arr = merchants.filter(
      (m) =>
        m.name.toLowerCase().includes(query.toLowerCase()) ||
        m.id.toLowerCase().includes(query.toLowerCase()) ||
        m.businessType.toLowerCase().includes(query.toLowerCase())
    );
    arr = [...arr].sort((a, b) =>
      sortDir === "desc" ? b.trustScore - a.trustScore : a.trustScore - b.trustScore
    );
    return arr;
  }, [query, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageData = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // For the global social graph, show a representative sample
  const graphIds = useMemo(() => merchants.slice(0, 30).map((m) => m.id), []);

  return (
    <div className="mx-auto max-w-7xl px-6 py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Trust scores, fraud rings, and merchant audit trail.
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <StatCard icon={Users} label="Total merchants" value={stats.total.toString()} tone="primary" />
        <StatCard icon={TrendingUp} label="Average trust score" value={stats.average.toString()} tone="success" />
        <StatCard icon={AlertTriangle} label="Fraud alerts detected" value={stats.fraudCount.toString()} tone="destructive" />
      </div>

      <div className="mt-8 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-border bg-card">
          <div className="flex flex-wrap items-center gap-3 border-b border-border p-4">
            <h2 className="text-sm font-semibold">Merchants</h2>
            <div className="relative ml-auto">
              <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => { setQuery(e.target.value); setPage(1); }}
                placeholder="Search by name, ID, business…"
                className="w-64 rounded-lg border border-input bg-background py-1.5 pl-8 pr-3 text-sm outline-none focus:border-primary"
              />
            </div>
            <button
              onClick={() => setSortDir((d) => (d === "desc" ? "asc" : "desc"))}
              className="inline-flex items-center gap-1 rounded-lg border border-input px-3 py-1.5 text-xs hover:bg-muted"
            >
              <ArrowUpDown className="h-3.5 w-3.5" />
              Trust {sortDir === "desc" ? "high → low" : "low → high"}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-muted-foreground">
                <tr className="border-b border-border">
                  <th className="px-4 py-3 text-left font-medium">Merchant</th>
                  <th className="px-4 py-3 text-left font-medium">Business</th>
                  <th className="px-4 py-3 text-left font-medium">Address</th>
                  <th className="px-4 py-3 text-right font-medium">Trust</th>
                  <th className="px-4 py-3 text-right font-medium">Δ 7d</th>
                  <th className="px-4 py-3 text-center font-medium">Flag</th>
                </tr>
              </thead>
              <tbody>
                {pageData.map((m) => (
                  <tr
                    key={m.id}
                    onClick={() => setSelected(m)}
                    className="cursor-pointer border-b border-border/60 transition hover:bg-muted/40"
                  >
                    <td className="px-4 py-3">
                      <div className="font-medium">{m.name}</div>
                      <div className="text-xs text-muted-foreground">{m.id}</div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{m.businessType}</td>
                    <td className="px-4 py-3 text-muted-foreground">{m.address}</td>
                    <td className="px-4 py-3 text-right">
                      <ScorePill score={m.trustScore} />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className={m.trustDelta >= 0 ? "text-success" : "text-destructive"}>
                        {m.trustDelta >= 0 ? <ArrowUp className="inline h-3 w-3" /> : <ArrowDown className="inline h-3 w-3" />}
                        {" "}{Math.abs(m.trustDelta).toFixed(1)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {m.fraudFlag ? (
                        <span
                          className={
                            "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs " +
                            (m.fraudFlag.severity === "high"
                              ? "bg-destructive/15 text-destructive"
                              : "bg-warning/20 text-warning-foreground")
                          }
                        >
                          <AlertTriangle className="h-3 w-3" />
                          {m.fraudFlag.severity}
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border p-3 text-xs text-muted-foreground">
            <span>
              Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
            </span>
            <div className="flex items-center gap-1">
              <button
                disabled={page === 1}
                onClick={() => setPage((p) => p - 1)}
                className="grid h-7 w-7 place-items-center rounded border border-input disabled:opacity-40"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="px-2">{page} / {totalPages}</span>
              <button
                disabled={page === totalPages}
                onClick={() => setPage((p) => p + 1)}
                className="grid h-7 w-7 place-items-center rounded border border-input disabled:opacity-40"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5">
          <h2 className="text-sm font-semibold">Recent audit trail</h2>
          <p className="text-xs text-muted-foreground">Score change events</p>
          <ul className="mt-4 space-y-3">
            {merchants.slice(0, 6).map((m) => (
              <li key={m.id} className="flex items-start gap-3 text-sm">
                <span
                  className={
                    "mt-1.5 h-2 w-2 shrink-0 rounded-full " +
                    (m.trustDelta >= 0 ? "bg-success" : "bg-destructive")
                  }
                />
                <div className="flex-1">
                  <div className="font-medium">{m.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {m.trustDelta >= 0 ? "Score up" : "Score down"} {Math.abs(m.trustDelta).toFixed(1)} pts
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">2d ago</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-8 rounded-2xl border border-border bg-card p-5">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold">Social graph</h2>
            <p className="text-xs text-muted-foreground">
              Green = healthy clusters · Red = flagged endorsement rings
            </p>
          </div>
        </div>
        <NetworkGraph merchantIds={graphIds} height={500} onNodeClick={(id) => {
          const m = merchants.find((x) => x.id === id);
          if (m) setSelected(m);
        }} />
      </div>

      {selected && <MerchantDetail merchant={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, tone }: any) {
  const toneClass =
    tone === "primary" ? "bg-primary/10 text-primary"
      : tone === "success" ? "bg-success/10 text-success"
      : "bg-destructive/10 text-destructive";
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
          <div className="mt-2 text-3xl font-bold">{value}</div>
        </div>
        <div className={"grid h-10 w-10 place-items-center rounded-xl " + toneClass}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

function ScorePill({ score }: { score: number }) {
  const t = trustLabel(score);
  return (
    <span className="inline-flex items-center gap-1.5 font-mono text-sm font-semibold">
      <span className={"h-1.5 w-1.5 rounded-full " + (
        score >= 65 ? "bg-success" : score >= 50 ? "bg-warning" : "bg-destructive"
      )} />
      {score} <span className={"text-xs font-normal " + t.color}>{t.label}</span>
    </span>
  );
}

function MerchantDetail({ merchant, onClose }: { merchant: Merchant; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm" onClick={onClose}>
      <div
        className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-border bg-card shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-border p-5">
          <div>
            <h2 className="text-xl font-bold">{merchant.name}</h2>
            <p className="text-sm text-muted-foreground">
              {merchant.id} · {merchant.businessType} · {merchant.address}
            </p>
          </div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-lg hover:bg-muted">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="grid gap-5 p-5 md:grid-cols-3">
          <div className="md:col-span-1 rounded-xl border border-border p-4">
            <div className="text-xs uppercase text-muted-foreground">Trust score</div>
            <div className="mt-1 text-5xl font-extrabold">{merchant.trustScore}</div>
            <div className={"mt-2 text-sm font-medium " + (merchant.trustDelta >= 0 ? "text-success" : "text-destructive")}>
              {merchant.trustDelta >= 0 ? "▲" : "▼"} {Math.abs(merchant.trustDelta).toFixed(1)} pts this week
            </div>
            <div className="mt-3 text-xs text-muted-foreground">
              At this rate, projected{" "}
              <strong className="text-foreground">
                {Math.max(0, Math.min(100, Math.round(merchant.trustScore + merchant.trustDelta * 4)))}
              </strong>{" "}
              in ~1 month.
            </div>
          </div>
          <div className="md:col-span-2 rounded-xl border border-border p-4">
            <div className="mb-1 text-xs uppercase text-muted-foreground">12-month trajectory</div>
            <TrustChart data={merchant.history} delta={merchant.trustDelta} />
          </div>
        </div>
        {merchant.fraudFlag && (
          <div className="mx-5 mb-5 flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm">
            <AlertTriangle className="mt-0.5 h-5 w-5 text-destructive" />
            <div>
              <div className="font-semibold text-destructive">
                Fraud flag · {merchant.fraudFlag.severity} severity
              </div>
              <div className="text-muted-foreground">{merchant.fraudFlag.reason}</div>
            </div>
          </div>
        )}
        <div className="border-t border-border p-5">
          <h3 className="mb-3 text-sm font-semibold">Audit trail</h3>
          <ul className="space-y-2">
            {merchant.history.slice(-5).reverse().map((h, i) => (
              <li key={i} className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{h.date}</span>
                <span className="font-mono">{h.score}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
