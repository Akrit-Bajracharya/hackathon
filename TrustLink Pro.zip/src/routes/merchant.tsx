import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useApp } from "@/lib/store";
import { AppShell } from "@/components/AppShell";
import { TrustGauge } from "@/components/TrustGauge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Share2, Brain, CheckCircle2, AlertCircle, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/merchant")({ component: MerchantPage });

function MerchantPage() {
  const { role, currentUser } = useApp();
  const nav = useNavigate();
  useEffect(() => { if (role !== "merchant") nav({ to: "/" }); }, [role, nav]);
  if (!currentUser) return null;

  const m = currentUser;
  const first = m.behavioralData[0].volume;
  const last = m.behavioralData[m.behavioralData.length - 1].volume;
  const rising = last >= first;
  const growth = Math.round(((last - first) / first) * 100);

  const positives = [
    "Consistent daily transaction frequency",
    "Strong endorsement chain (verified by 1 referrer)",
    "Healthy weekday-to-weekend transaction ratio",
  ];
  const negatives = [
    "Weekend transaction consistency lower than peers",
    "Limited customer retention signal — many one-time buyers",
    "Few cross-merchant endorsements in your network",
  ];

  return (
    <AppShell>
      {/* Header */}
      <div className="bg-card border border-border rounded-2xl p-6 mb-4 flex flex-col md:flex-row gap-6 items-center md:items-start">
        <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground flex items-center justify-center text-2xl font-bold shadow-lg shadow-primary/30">
          {m.name.split(" ").map((s) => s[0]).join("").slice(0, 2)}
        </div>
        <div className="flex-1 text-center md:text-left">
          <h1 className="text-2xl font-bold text-foreground">{m.name}</h1>
          <p className="text-sm text-muted-foreground">{m.businessType} · {m.address}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Merchant ID: <span className="font-mono text-foreground">{m.id}</span></p>
        </div>
      </div>

      {/* Centerpiece */}
      <div className="bg-gradient-to-br from-primary/10 via-card to-card border border-primary/20 rounded-2xl p-8 mb-4 flex flex-col items-center">
        <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">Your Trust Score</div>
        <TrustGauge score={m.trustScore} size={280} label="Overall Trust" />
        <p className="mt-6 text-center text-sm text-foreground max-w-xl leading-relaxed">
          Your trust score reflects how reliably your business operates as seen through your transaction patterns,
          repayment behavior, and the trust other merchants place in you. A higher score unlocks better loan offers,
          larger limits, and lower interest rates.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {/* Trajectory chart */}
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="text-sm font-bold text-foreground">Trust Trajectory</h3>
              <p className="text-xs text-muted-foreground">12-month direction & projection</p>
            </div>
            <span className={`px-2.5 py-1 rounded-md text-xs font-bold flex items-center gap-1 ${rising ? "bg-primary/15 text-primary" : "bg-destructive/15 text-destructive"}`}>
              {rising ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
              {growth > 0 ? "+" : ""}{growth}%
            </span>
          </div>
          <div className="h-56">
            <ResponsiveContainer>
              <LineChart data={m.behavioralData} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0.01 240)" />
                <XAxis dataKey="timestamp" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid oklch(0.92 0.01 240)" }} />
                <Line type="monotone" dataKey="volume" stroke="oklch(0.68 0.18 142)" strokeWidth={3} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {rising
              ? `If your current pattern holds, expect to reach the next trust tier in approximately 3 months.`
              : `Your trajectory has softened. Re-engaging consistent daily transactions can reverse this within 2 months.`}
          </p>
        </div>

        {/* Improvement lists */}
        <div className="bg-card border border-border rounded-2xl p-5">
          <h3 className="text-sm font-bold text-foreground mb-3">How to Improve Your Score</h3>
          <div className="space-y-2 mb-4">
            {positives.map((t, i) => (
              <div key={i} className="flex items-start gap-2 px-3 py-2 rounded-lg bg-primary/8 border border-primary/15">
                <CheckCircle2 className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-xs text-foreground">{t}</span>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            {negatives.map((t, i) => (
              <div key={i} className="flex items-start gap-2 px-3 py-2 rounded-lg bg-destructive/8 border border-destructive/15">
                <AlertCircle className="h-4 w-4 text-destructive mt-0.5 shrink-0" />
                <span className="text-xs text-foreground">{t}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link to="/quiz" className="group bg-card hover:bg-muted/40 border border-border rounded-2xl p-5 flex items-center gap-4 transition">
          <div className="h-12 w-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Brain className="h-6 w-6" /></div>
          <div className="flex-1">
            <div className="text-sm font-bold text-foreground">Take the Trust Assessment</div>
            <div className="text-xs text-muted-foreground">10 quick questions · ~2 minutes</div>
          </div>
          <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition" />
        </Link>
        <Link to="/network" className="group bg-card hover:bg-muted/40 border border-border rounded-2xl p-5 flex items-center gap-4 transition">
          <div className="h-12 w-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Share2 className="h-6 w-6" /></div>
          <div className="flex-1">
            <div className="text-sm font-bold text-foreground">View Connections</div>
            <div className="text-xs text-muted-foreground">{m.socialConnections.length} merchants in your network</div>
          </div>
          <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition" />
        </Link>
      </div>
    </AppShell>
  );
}