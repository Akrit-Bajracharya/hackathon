import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useApp } from "@/lib/store";
import { AppShell } from "@/components/AppShell";
import { QUIZ_QUESTIONS } from "@/lib/mockData";
import { ArrowLeft, Check, Sparkles } from "lucide-react";

export const Route = createFileRoute("/quiz")({ component: QuizPage });

function QuizPage() {
  const { role, setQuizAnswers } = useApp();
  const nav = useNavigate();
  useEffect(() => { if (role !== "merchant") nav({ to: "/" }); }, [role, nav]);

  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [done, setDone] = useState(false);

  const total = QUIZ_QUESTIONS.length;
  const q = QUIZ_QUESTIONS[step];

  const choose = (optIdx: number) => {
    const next = { ...answers, [step]: optIdx };
    setAnswers(next);
    setTimeout(() => {
      if (step === total - 1) {
        const mapped: Record<string, number> = {};
        QUIZ_QUESTIONS.forEach((qq, i) => {
          const a = next[i];
          if (a !== undefined) mapped[`q${i + 1}`] = qq.options[a].score;
        });
        setQuizAnswers(mapped);
        setDone(true);
      } else setStep((s) => s + 1);
    }, 220);
  };

  if (done) {
    return (
      <AppShell>
        <div className="min-h-[70vh] flex flex-col items-center justify-center text-center">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/30 blur-3xl rounded-full animate-pulse" />
            <div className="relative h-28 w-28 rounded-full bg-primary flex items-center justify-center shadow-2xl shadow-primary/40 animate-[scale-in_0.4s_ease-out]">
              <Check className="h-14 w-14 text-primary-foreground" strokeWidth={3} />
            </div>
          </div>
          <h1 className="mt-8 text-3xl font-bold text-foreground animate-[fade-in_0.5s_ease-out]">Quiz complete!</h1>
          <p className="mt-2 text-sm text-muted-foreground max-w-md">Thanks for completing the assessment. Your responses have been recorded and will inform your trust profile.</p>
          <button onClick={() => nav({ to: "/merchant" })}
            className="mt-8 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/30 hover:shadow-primary/50 hover:translate-y-[-1px] transition flex items-center gap-2">
            Back to Profile <Sparkles className="h-4 w-4" />
          </button>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            <span className="font-semibold uppercase tracking-wider">Question {step + 1} of {total}</span>
            <span>{Math.round(((step + 1) / total) * 100)}%</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${((step + 1) / total) * 100}%` }} />
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl p-6 sm:p-8 shadow-sm" key={step}>
          <h2 className="text-xl sm:text-2xl font-bold text-foreground leading-snug animate-[fade-in_0.3s_ease-out]">{q.q}</h2>
          <div className="mt-6 space-y-3">
            {q.options.map((opt, i) => {
              const selected = answers[step] === i;
              return (
                <button key={i} onClick={() => choose(i)}
                  className={`w-full text-left px-5 py-4 rounded-xl border-2 text-sm sm:text-base font-medium transition-all hover:translate-x-1 ${selected ? "border-primary bg-primary/10 text-foreground shadow-md shadow-primary/20" : "border-border bg-background text-foreground hover:border-primary/50 hover:bg-muted/40"}`}>
                  <div className="flex items-center gap-3">
                    <div className={`h-7 w-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${selected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                      {String.fromCharCode(65 + i)}
                    </div>
                    <span>{opt.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-4 flex justify-between">
          <button onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0}
            className="px-4 py-2 rounded-lg text-sm font-semibold text-foreground border border-border bg-card hover:bg-muted transition disabled:opacity-40 flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />Back
          </button>
          <p className="text-xs text-muted-foreground self-center">Tap an answer to continue — you can change earlier choices.</p>
        </div>
      </div>
    </AppShell>
  );
}