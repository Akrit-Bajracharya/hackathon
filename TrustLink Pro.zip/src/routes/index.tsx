import { createFileRoute } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, ArrowRight } from "lucide-react";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "eSewa Trust — Merchant Lending Middleware" },
      { name: "description", content: "Collateral-free micro-lending trust middleware for eSewa merchants." },
      { property: "og:title", content: "eSewa Trust" },
      { property: "og:description", content: "Trust Middleware for Merchant Lending" },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const { login } = useApp();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    setTimeout(() => {
      const role = login(email);
      navigate({ to: role === "admin" ? "/admin" : "/merchant" });
    }, 500);
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-background flex items-center justify-center p-6">
      <div className="absolute inset-0 -z-10">
        <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
      </div>
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-border bg-card/80 backdrop-blur-xl shadow-2xl shadow-primary/5 p-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="h-11 w-11 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
              <ShieldCheck className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground leading-tight">eSewa Trust</h1>
              <p className="text-xs text-muted-foreground">Trust Middleware for Merchant Lending</p>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-4 mb-6">Sign in to access your merchant trust profile.</p>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-foreground/80">Mobile or Email</label>
              <input
                type="text"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="merchant@example.com"
                className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition"
                required
              />
            </div>
            <div>
              <label className="text-xs font-medium text-foreground/80">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="group w-full rounded-lg bg-primary text-primary-foreground py-2.5 text-sm font-semibold shadow-lg shadow-primary/30 hover:shadow-primary/50 hover:translate-y-[-1px] transition disabled:opacity-60 flex items-center justify-center gap-2"
            >
              {loading ? "Authenticating..." : <>Continue <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition" /></>}
            </button>
          </form>
          <div className="mt-6 text-[11px] text-muted-foreground border-t border-border pt-4 leading-relaxed">
            <span className="font-semibold text-foreground/80">Demo:</span> use <code className="text-primary">admin@esewa.com</code> for the admin dashboard, any other email for the merchant view. Any password works.
          </div>
        </div>
      </div>
    </div>
  );
}
