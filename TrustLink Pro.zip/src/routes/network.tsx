import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useApp } from "@/lib/store";
import { AppShell } from "@/components/AppShell";
import { ZoomIn, ZoomOut, UserPlus, X, Check } from "lucide-react";

export const Route = createFileRoute("/network")({ component: NetworkPage });

function NetworkPage() {
  const { role, currentUser, merchants } = useApp();
  const nav = useNavigate();
  useEffect(() => { if (role !== "merchant") nav({ to: "/" }); }, [role, nav]);
  if (!currentUser) return null;

  const me = currentUser;
  const [zoom, setZoom] = useState(1);
  const [hovered, setHovered] = useState<string | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [endorseId, setEndorseId] = useState("");
  const [confirm, setConfirm] = useState(false);

  const connections = useMemo(() => me.socialConnections.map((c) => {
    const target = merchants.find((m) => m.id === c.targetId);
    return { ...c, name: target?.name ?? c.targetId };
  }), [me, merchants]);

  const cx = 260, cy = 220;
  const radius = 150;

  const edgeColor = (t: string) => t === "endorser" ? "oklch(0.6 0.16 250)" : t === "transaction" ? "oklch(0.78 0.14 90)" : "oklch(0.68 0.18 142)";

  return (
    <AppShell>
      <div className="grid grid-cols-12 gap-4">
        {/* Sidebar */}
        <aside className="col-span-12 lg:col-span-4 bg-card border border-border rounded-2xl overflow-hidden flex flex-col" style={{ minHeight: 540 }}>
          <div className="p-4 border-b border-border">
            <h2 className="text-sm font-bold text-foreground">Your Connections</h2>
            <p className="text-xs text-muted-foreground">{connections.length} active merchants in your trust network</p>
          </div>
          <div className="flex-1 overflow-auto divide-y divide-border">
            {connections.map((c) => {
              const open = selected === c.targetId;
              return (
                <div key={c.targetId} className={`px-4 py-3 transition ${open ? "bg-primary/5" : "hover:bg-muted/40"}`}>
                  <button onClick={() => setSelected(open ? null : c.targetId)} className="w-full text-left flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary to-primary/60 text-primary-foreground flex items-center justify-center text-xs font-bold">
                      {c.name.split(" ").map((s) => s[0]).join("").slice(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-foreground truncate">{c.name}</div>
                      <div className="text-[11px] text-muted-foreground">{c.targetId}</div>
                    </div>
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: edgeColor(c.type) }} />
                  </button>
                  {open && (
                    <div className="mt-3 pl-13 space-y-1 text-xs animate-[fade-in_0.2s_ease-out]">
                      <Detail label="Relationship">{c.type === "both" ? "Endorser + Transaction Partner" : c.type === "endorser" ? "Endorser" : "Transaction Partner"}</Detail>
                      <Detail label="Frequency">{c.weight >= 7 ? "High" : c.weight >= 4 ? "Medium" : "Low"}</Detail>
                      <Detail label="Shared transactions">{c.weight * 4}</Detail>
                      <Detail label="Duration">{c.weight * 3} months</Detail>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </aside>

        {/* Graph */}
        <section className="col-span-12 lg:col-span-8 bg-card border border-border rounded-2xl p-4 relative overflow-hidden" style={{ minHeight: 540 }}>
          <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
            <button onClick={() => setZoom((z) => Math.max(0.6, z - 0.15))} className="h-9 w-9 rounded-lg bg-background border border-border hover:bg-muted flex items-center justify-center"><ZoomOut className="h-4 w-4" /></button>
            <button onClick={() => setZoom((z) => Math.min(1.8, z + 0.15))} className="h-9 w-9 rounded-lg bg-background border border-border hover:bg-muted flex items-center justify-center"><ZoomIn className="h-4 w-4" /></button>
            <button onClick={() => { setModalOpen(true); setConfirm(false); setEndorseId(""); }}
              className="h-9 px-3 rounded-lg bg-primary text-primary-foreground font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-primary/30 hover:shadow-primary/50 transition">
              <UserPlus className="h-4 w-4" />Endorse Merchant
            </button>
          </div>

          <svg viewBox="0 0 520 440" className="w-full h-full" style={{ transform: `scale(${zoom})`, transition: "transform .2s" }}>
            {/* Edges */}
            {connections.map((c, i) => {
              const a = (i / connections.length) * Math.PI * 2 - Math.PI / 2;
              const x = cx + Math.cos(a) * radius;
              const y = cy + Math.sin(a) * radius;
              const isHover = hovered === c.targetId;
              return (
                <g key={c.targetId}>
                  <line x1={cx} y1={cy} x2={x} y2={y}
                    stroke={edgeColor(c.type)}
                    strokeWidth={1 + c.weight * 0.7}
                    opacity={isHover ? 1 : 0.65}
                    onMouseEnter={() => setHovered(c.targetId)}
                    onMouseLeave={() => setHovered(null)}
                    style={{ cursor: "pointer" }}
                  />
                </g>
              );
            })}
            {/* Nodes */}
            {connections.map((c, i) => {
              const a = (i / connections.length) * Math.PI * 2 - Math.PI / 2;
              const x = cx + Math.cos(a) * radius;
              const y = cy + Math.sin(a) * radius;
              const isHover = hovered === c.targetId;
              return (
                <g key={c.targetId} style={{ cursor: "pointer" }}
                  onMouseEnter={() => setHovered(c.targetId)} onMouseLeave={() => setHovered(null)}>
                  <circle cx={x} cy={y} r={isHover ? 26 : 22} fill="white" stroke={edgeColor(c.type)} strokeWidth={3} />
                  <text x={x} y={y + 4} textAnchor="middle" fontSize="10" fontWeight="700" fill="oklch(0.22 0.03 250)">
                    {c.name.split(" ").map((s) => s[0]).join("").slice(0, 2)}
                  </text>
                </g>
              );
            })}
            {/* Center */}
            <circle cx={cx} cy={cy} r={38} fill="oklch(0.68 0.18 142)" />
            <circle cx={cx} cy={cy} r={44} fill="none" stroke="oklch(0.68 0.18 142)" strokeWidth={2} opacity={0.3} />
            <text x={cx} y={cy + 5} textAnchor="middle" fontSize="13" fontWeight="800" fill="white">YOU</text>
          </svg>

          {hovered && (() => {
            const c = connections.find((x) => x.targetId === hovered);
            if (!c) return null;
            return (
              <div className="absolute bottom-4 left-4 bg-card border border-border rounded-xl shadow-xl px-4 py-3 text-xs animate-[fade-in_0.15s_ease-out]">
                <div className="font-bold text-sm text-foreground">{c.name}</div>
                <div className="text-muted-foreground mt-1 space-y-0.5">
                  <div><span className="font-semibold">{c.weight * 4}</span> shared transactions</div>
                  <div><span className="font-semibold">{c.weight * 3}</span> months active</div>
                  <div className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full" style={{ backgroundColor: edgeColor(c.type) }} />{c.type === "both" ? "Endorser + Transaction" : c.type === "endorser" ? "Endorser" : "Transaction Partner"}</div>
                </div>
              </div>
            );
          })()}

          {/* Legend */}
          <div className="absolute bottom-4 right-4 flex flex-col gap-1 text-[11px] bg-card/90 backdrop-blur border border-border rounded-lg px-3 py-2">
            <span className="flex items-center gap-2"><span className="h-0.5 w-4 bg-[oklch(0.6_0.16_250)]" />Endorser</span>
            <span className="flex items-center gap-2"><span className="h-0.5 w-4 bg-[oklch(0.78_0.14_90)]" />Transaction</span>
            <span className="flex items-center gap-2"><span className="h-0.5 w-4 bg-[oklch(0.68_0.18_142)]" />Both</span>
          </div>
        </section>
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-foreground/40 backdrop-blur-sm animate-[fade-in_0.2s_ease-out]" onClick={() => setModalOpen(false)}>
          <div className="w-full max-w-md bg-card rounded-2xl border border-border shadow-2xl p-6 animate-[scale-in_0.2s_ease-out]" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-foreground">Endorse a New Merchant</h3>
              <button onClick={() => setModalOpen(false)} className="h-8 w-8 rounded-lg hover:bg-muted flex items-center justify-center"><X className="h-4 w-4" /></button>
            </div>
            {confirm ? (
              <div className="text-center py-6">
                <div className="h-14 w-14 mx-auto rounded-full bg-primary flex items-center justify-center mb-3 shadow-lg shadow-primary/30">
                  <Check className="h-7 w-7 text-primary-foreground" strokeWidth={3} />
                </div>
                <p className="font-semibold text-foreground">Endorsement submitted</p>
                <p className="text-xs text-muted-foreground mt-1">Your endorsement of <span className="font-mono">{endorseId || "this merchant"}</span> is being reviewed.</p>
                <button onClick={() => setModalOpen(false)} className="mt-5 px-5 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-semibold">Done</button>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setConfirm(true); }} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-foreground/80">Merchant ID</label>
                  <input value={endorseId} onChange={(e) => setEndorseId(e.target.value)} placeholder="ESW-1042" required
                    className="mt-1 w-full px-3 py-2.5 rounded-lg border border-input bg-background text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground/80">Endorsement strength</label>
                  <select className="mt-1 w-full px-3 py-2.5 rounded-lg border border-input bg-background text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary">
                    <option>Strong — I vouch fully</option>
                    <option>Moderate — Reliable partner</option>
                    <option>Light — Limited history</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground/80">Note (optional)</label>
                  <textarea rows={3} placeholder="Why are you endorsing this merchant?"
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-input bg-background text-sm outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none" />
                </div>
                <button type="submit" className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground font-semibold text-sm shadow-md shadow-primary/30 hover:shadow-primary/50 transition">Submit Endorsement</button>
              </form>
            )}
          </div>
        </div>
      )}
    </AppShell>
  );
}

function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="flex justify-between gap-3 text-foreground"><span className="text-muted-foreground">{label}</span><span className="font-semibold">{children}</span></div>;
}