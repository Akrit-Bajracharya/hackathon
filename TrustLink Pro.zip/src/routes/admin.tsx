import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useApp } from "@/lib/store";
import { AppShell } from "@/components/AppShell";
import { TrustGauge } from "@/components/TrustGauge";
import type { MerchantData } from "@/lib/mockData";
import { Search, ArrowUpDown, Users, Gauge, AlertTriangle, Star, ShieldAlert, Sparkles, ChevronLeft, ChevronRight } from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  PieChart, Pie, Cell, Legend, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
} from "recharts";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const { role, merchants, selectedMerchantId, selectMerchant } = useApp();
  const nav = useNavigate();
  useEffect(() => { if (role !== "admin") nav({ to: "/" }); }, [role, nav]);

  const [query, setQuery] = useState("");
  const [sortDir, setSortDir] = useState<"high" | "low">("high");
  const [page, setPage] = useState(1);
  const perPage = 12;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = merchants.filter((m) => !q || m.name.toLowerCase().includes(q) || m.id.toLowerCase().includes(q));
    return [...list].sort((a, b) => sortDir === "high" ? b.trustScore - a.trustScore : a.trustScore - b.trustScore);
  }, [merchants, query, sortDir]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / perPage));
  const pageItems = filtered.slice((page - 1) * perPage, page * perPage);
  const selected = merchants.find((m) => m.id === selectedMerchantId) ?? null;

  const avgScore = Math.round(merchants.reduce((s, m) => s + m.trustScore, 0) / merchants.length);
  const fraudCount = merchants.filter((m) => m.flagged).length;

  if (role !== "admin") return null;

  return (
    <AppShell>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <StatCard icon={Users} label="Total Merchants" value={merchants.length.toString()} accent="primary" />
        <StatCard icon={Gauge} label="Average Trust Score" value={avgScore.toString()} accent="primary" />
        <StatCard icon={AlertTriangle} label="Active Fraud Alerts" value={fraudCount.toString()} accent="danger" />
      </div>

      <div className="grid grid-cols-12 gap-4">
        {/* Directory */}
        <div className="col-span-12 lg:col-span-4 bg-card border border-border rounded-2xl overflow-hidden flex flex-col" style={{ minHeight: 600 }}>
          <div className="p-4 border-b border-border space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }}
                placeholder="Search merchant or ID..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-background border border-input rounded-lg outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary" />
            </div>
            <button onClick={() => setSortDir((d) => d === "high" ? "low" : "high")}
              className="w-full flex items-center justify-between px-3 py-1.5 text-xs font-medium text-foreground bg-muted hover:bg-accent rounded-lg transition">
              <span className="flex items-center gap-1.5"><ArrowUpDown className="h-3.5 w-3.5" />Sort by Trust Score</span>
              <span className="text-primary font-semibold">{sortDir === "high" ? "High → Low" : "Low → High"}</span>
            </button>
          </div>
          <div className="flex-1 overflow-auto divide-y divide-border">
            {pageItems.map((m) => {
              const active = m.id === selectedMerchantId;
              return (
                <button key={m.id} onClick={() => selectMerchant(m.id)}
                  className={`w-full text-left px-4 py-3 transition flex items-center gap-3 ${active ? "bg-primary/10" : "hover:bg-muted/60"}`}>
                  <div className={`h-9 w-9 rounded-full flex items-center justify-center text-xs font-bold ${active ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                    {m.name.split(" ").map((s) => s[0]).join("").slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground truncate">
                      {m.name} {m.flagged && <ShieldAlert className="h-3.5 w-3.5 text-destructive" />}
                    </div>
                    <div className="text-[11px] text-muted-foreground truncate">{m.id} · {m.address}</div>
                  </div>
                  <ScorePill score={m.trustScore} />
                </button>
              );
            })}
          </div>
          <div className="border-t border-border px-4 py-2 flex items-center justify-between text-xs text-muted-foreground">
            <span>{filtered.length} merchants</span>
            <div className="flex items-center gap-2">
              <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
                className="p-1 rounded hover:bg-muted disabled:opacity-30"><ChevronLeft className="h-4 w-4" /></button>
              <span>{page} / {pageCount}</span>
              <button onClick={() => setPage((p) => Math.min(pageCount, p + 1))} disabled={page === pageCount}
                className="p-1 rounded hover:bg-muted disabled:opacity-30"><ChevronRight className="h-4 w-4" /></button>
            </div>
          </div>
        </div>

        {/* Workspace */}
        <div className="col-span-12 lg:col-span-8">
          {selected ? <Workspace merchant={selected} /> : <EmptyWorkspace />}
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({ icon: Icon, label, value, accent }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; accent: "primary" | "danger" }) {
  const color = accent === "danger" ? "text-destructive bg-destructive/10" : "text-primary bg-primary/10";
  return (
    <div className="bg-card border border-border rounded-2xl p-5 flex items-center gap-4">
      <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${color}`}><Icon className="h-6 w-6" /></div>
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-2xl font-bold text-foreground tabular-nums">{value}</div>
      </div>
    </div>
  );
}

function ScorePill({ score }: { score: number }) {
  const color = score >= 750 ? "bg-primary/15 text-primary" : score >= 600 ? "bg-amber-500/15 text-amber-600" : "bg-destructive/15 text-destructive";
  return <span className={`px-2 py-0.5 text-xs font-bold rounded-md tabular-nums ${color}`}>{score}</span>;
}

function EmptyWorkspace() {
  return (
    <div className="h-full min-h-[600px] bg-card border border-dashed border-border rounded-2xl flex flex-col items-center justify-center text-center p-8">
      <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
        <Users className="h-8 w-8 text-primary" />
      </div>
      <h3 className="text-lg font-semibold text-foreground">Select a merchant to begin</h3>
      <p className="text-sm text-muted-foreground max-w-sm mt-1">Choose a merchant from the directory to load their full trust profile, behavioral analytics, and risk indicators.</p>
    </div>
  );
}

function Workspace({ merchant }: { merchant: MerchantData }) {
  const { setCalculatedScore } = useApp();
  const [calculating, setCalculating] = useState(false);

  const runAdvanced = () => {
    setCalculating(true);
    setTimeout(() => {
      const trend = merchant.behavioralData.map((d) => d.volume);
      const trendScore = trend[trend.length - 1] > trend[0] ? 1 : -1;
      const psych = Object.values(merchant.psychometric).reduce((a, b) => a + b, 0) / 5;
      const social = merchant.socialConnections.reduce((a, c) => a + c.weight, 0);
      const composite = Math.round(450 + psych * 2.5 + social * 4 + trendScore * 30 + (merchant.flagged ? -80 : 40));
      setCalculatedScore(merchant.id, Math.max(300, Math.min(900, composite)));
      setCalculating(false);
    }, 1600);
  };

  return (
    <div className="space-y-4">
      <div className="bg-card border border-border rounded-2xl p-5 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground flex items-center justify-center text-lg font-bold shadow-lg shadow-primary/20">
            {merchant.name.split(" ").map((s) => s[0]).join("").slice(0, 2)}
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2">{merchant.name}
              {merchant.flagged && <span className="px-2 py-0.5 text-[10px] uppercase font-bold rounded bg-destructive/15 text-destructive flex items-center gap-1"><ShieldAlert className="h-3 w-3" />Flagged</span>}
            </h2>
            <div className="text-xs text-muted-foreground">{merchant.id} · {merchant.businessType} · {merchant.address}</div>
          </div>
        </div>
        <ScorePill score={merchant.trustScore} />
      </div>

      {/* Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <PanelCard title="Behavioral Analytics" subtitle="Transaction volume + 3-month regression forecast" className="lg:col-span-2">
          <BehavioralChart merchant={merchant} />
        </PanelCard>
        <PanelCard title="Transaction Mix" subtitle="QR Scans vs P2P">
          <CategoryPie merchant={merchant} />
        </PanelCard>
      </div>

      {/* Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <PanelCard title="Psychometric Profile" subtitle="Behavioral discipline radar" className="lg:col-span-2">
          <PsychRadar merchant={merchant} />
        </PanelCard>
        <PanelCard title="Social Voucher" subtitle="Endorsement chain">
          <Voucher merchant={merchant} />
        </PanelCard>
      </div>

      {/* Row 3 */}
      <PanelCard title="Fraud Detection" subtitle="Social ring & loop analysis">
        <FraudGraph merchant={merchant} />
      </PanelCard>

      {/* Row 4 */}
      <PanelCard title="Audit Trail" subtitle="Historical score fluctuations">
        <AuditTimeline merchant={merchant} />
      </PanelCard>

      {/* Action */}
      <div className="bg-gradient-to-br from-primary/10 via-card to-card border border-primary/20 rounded-2xl p-6">
        {merchant.calculatedTrustScore === null ? (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-foreground flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" />Advanced Trust Analytics</h3>
              <p className="text-sm text-muted-foreground mt-1">Run the composite model to derive a definitive Overall Trust Score for this merchant.</p>
            </div>
            <button onClick={runAdvanced} disabled={calculating}
              className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/30 hover:shadow-primary/50 hover:translate-y-[-1px] transition disabled:opacity-60 flex items-center gap-2 whitespace-nowrap">
              {calculating ? (<><span className="h-4 w-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />Calculating…</>) : (<>Start Advanced Analytics<Sparkles className="h-4 w-4" /></>)}
            </button>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Definitive composite</div>
              <h3 className="text-2xl font-bold text-foreground">Overall Trust Score</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-md">Derived from behavioral, psychometric and social signals weighted by fraud-risk dampening.</p>
              <button onClick={runAdvanced} className="mt-3 text-xs text-primary font-semibold hover:underline">Recalculate →</button>
            </div>
            <TrustGauge score={merchant.calculatedTrustScore} />
          </div>
        )}
      </div>
    </div>
  );
}

function PanelCard({ title, subtitle, children, className = "" }: { title: string; subtitle?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-card border border-border rounded-2xl p-5 ${className}`}>
      <div className="mb-3">
        <h3 className="text-sm font-bold text-foreground">{title}</h3>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

function BehavioralChart({ merchant }: { merchant: MerchantData }) {
  // Linear regression on existing 12 months → forecast next 3
  const data = merchant.behavioralData.map((d, i) => ({ x: i, label: d.timestamp, volume: d.volume }));
  const n = data.length;
  const sumX = data.reduce((s, p) => s + p.x, 0);
  const sumY = data.reduce((s, p) => s + p.volume, 0);
  const sumXY = data.reduce((s, p) => s + p.x * p.volume, 0);
  const sumXX = data.reduce((s, p) => s + p.x * p.x, 0);
  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  const all = [
    ...data.map((p) => ({ label: p.label, volume: p.volume, trend: Math.round(intercept + slope * p.x) })),
    ...Array.from({ length: 3 }, (_, i) => {
      const x = n + i;
      const last = new Date("2026-05-30"); last.setMonth(last.getMonth() + i + 1);
      return { label: last.toLocaleDateString("en-US", { month: "short", year: "2-digit" }), volume: undefined as number | undefined, trend: Math.round(intercept + slope * x), forecast: Math.round(intercept + slope * x) };
    }),
  ];

  return (
    <div className="h-64">
      <ResponsiveContainer>
        <LineChart data={all} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0.01 240)" />
          <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="oklch(0.6 0.02 250)" />
          <YAxis tick={{ fontSize: 11 }} stroke="oklch(0.6 0.02 250)" tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
          <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid oklch(0.92 0.01 240)" }} />
          <Line type="monotone" dataKey="volume" stroke="oklch(0.68 0.18 142)" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} name="Actual Volume" />
          <Line type="monotone" dataKey="trend" stroke="oklch(0.55 0.15 250)" strokeWidth={2} strokeDasharray="6 4" dot={false} name="Regression Trend" />
          <Line type="monotone" dataKey="forecast" stroke="oklch(0.68 0.18 142)" strokeWidth={2} strokeDasharray="2 4" dot={{ r: 3 }} name="Forecast (3mo)" />
          <Legend wrapperStyle={{ fontSize: 11 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function CategoryPie({ merchant }: { merchant: MerchantData }) {
  const data = [
    { name: "QR Scans", value: merchant.txCategories.qr },
    { name: "P2P Transfers", value: merchant.txCategories.p2p },
  ];
  const colors = ["oklch(0.68 0.18 142)", "oklch(0.55 0.15 250)"];
  return (
    <div className="h-64">
      <ResponsiveContainer>
        <PieChart>
          <Pie data={data} dataKey="value" innerRadius={50} outerRadius={80} paddingAngle={4}>
            {data.map((_, i) => <Cell key={i} fill={colors[i]} />)}
          </Pie>
          <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid oklch(0.92 0.01 240)" }} />
          <Legend wrapperStyle={{ fontSize: 11 }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

function PsychRadar({ merchant }: { merchant: MerchantData }) {
  const data = Object.entries(merchant.psychometric).map(([k, v]) => ({ attribute: k, value: v }));
  return (
    <div className="h-64">
      <ResponsiveContainer>
        <RadarChart data={data}>
          <PolarGrid stroke="oklch(0.92 0.01 240)" />
          <PolarAngleAxis dataKey="attribute" tick={{ fontSize: 11, fill: "oklch(0.35 0.03 250)" }} />
          <PolarRadiusAxis angle={90} domain={[0, 100]} tick={false} stroke="oklch(0.92 0.01 240)" />
          <Radar name="Score" dataKey="value" stroke="oklch(0.68 0.18 142)" fill="oklch(0.68 0.18 142)" fillOpacity={0.35} strokeWidth={2} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}

function Voucher({ merchant }: { merchant: MerchantData }) {
  const { rating, name, id } = merchant.endorsedBy;
  return (
    <div className="h-full flex flex-col">
      <div className="rounded-xl border border-border bg-muted/40 p-4 mb-3">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Referred By</div>
        <div className="text-base font-bold text-foreground">{name}</div>
        <div className="text-xs text-muted-foreground">{id}</div>
      </div>
      <div className="flex items-center gap-1 mb-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className={`h-6 w-6 ${i < rating ? "text-primary fill-primary" : "text-muted-foreground/30"}`} />
        ))}
        <span className="ml-2 text-sm font-semibold text-foreground">{rating}.0 / 5.0</span>
      </div>
      <div className="mt-auto flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 text-primary text-xs font-medium">
        <ShieldAlert className="h-4 w-4" />Trust chain verified
      </div>
    </div>
  );
}

function FraudGraph({ merchant }: { merchant: MerchantData }) {
  const cx = 240, cy = 130, r = 90;
  const nodes = merchant.socialConnections.slice(0, 8).map((c, i, arr) => ({
    id: c.targetId,
    angle: (i / arr.length) * Math.PI * 2,
    weight: c.weight,
    type: c.type,
  }));
  const flagged = merchant.flagged;
  const ringColor = flagged ? "oklch(0.65 0.22 25)" : "oklch(0.68 0.18 142)";
  return (
    <div className="overflow-x-auto">
      <svg width="100%" viewBox="0 0 480 260" className="min-w-[460px]">
        {nodes.map((n) => {
          const x = cx + Math.cos(n.angle) * r;
          const y = cy + Math.sin(n.angle) * r;
          return <line key={`l${n.id}`} x1={cx} y1={cy} x2={x} y2={y} stroke={ringColor} strokeWidth={1 + n.weight / 4} opacity={0.55} />;
        })}
        {flagged && nodes.slice(0, 3).map((n, i, arr) => {
          const next = arr[(i + 1) % arr.length];
          const x1 = cx + Math.cos(n.angle) * r, y1 = cy + Math.sin(n.angle) * r;
          const x2 = cx + Math.cos(next.angle) * r, y2 = cy + Math.sin(next.angle) * r;
          return <line key={`r${i}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke="oklch(0.65 0.22 25)" strokeWidth={2.5} strokeDasharray="4 3" />;
        })}
        {nodes.map((n) => {
          const x = cx + Math.cos(n.angle) * r;
          const y = cy + Math.sin(n.angle) * r;
          return (
            <g key={n.id}>
              <circle cx={x} cy={y} r={14} fill={ringColor} opacity={0.85} />
              <text x={x} y={y + 3} textAnchor="middle" fontSize="9" fill="white" fontWeight="600">{n.id.slice(-3)}</text>
            </g>
          );
        })}
        <circle cx={cx} cy={cy} r={24} fill="oklch(0.22 0.03 250)" />
        <text x={cx} y={cy + 4} textAnchor="middle" fontSize="10" fill="white" fontWeight="700">YOU</text>
      </svg>
      <div className="mt-2 flex items-center gap-4 text-xs">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-primary" />Healthy cluster</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-destructive" />Suspected ring</span>
        {flagged && <span className="ml-auto text-destructive font-semibold flex items-center gap-1"><ShieldAlert className="h-3.5 w-3.5" />Artificial boosting loop detected</span>}
      </div>
    </div>
  );
}

function AuditTimeline({ merchant }: { merchant: MerchantData }) {
  return (
    <ol className="relative border-l-2 border-border ml-3 space-y-4 py-2">
      {merchant.auditTrail.map((a, i) => (
        <li key={i} className="pl-5 relative">
          <span className={`absolute -left-[7px] top-1.5 h-3 w-3 rounded-full ring-4 ring-card ${a.delta > 0 ? "bg-primary" : a.delta < 0 ? "bg-destructive" : "bg-muted-foreground"}`} />
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-foreground">{a.date}</span>
            <span className={`text-xs px-1.5 py-0.5 rounded-md font-bold tabular-nums ${a.delta > 0 ? "bg-primary/15 text-primary" : a.delta < 0 ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`}>
              {a.delta > 0 ? "+" : ""}{a.delta}
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">{a.event}</p>
        </li>
      ))}
    </ol>
  );
}