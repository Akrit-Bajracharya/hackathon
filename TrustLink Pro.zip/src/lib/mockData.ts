const FIRST = ["Aarav","Bishal","Chitra","Diya","Eshan","Falguni","Gaurav","Hari","Ishan","Jaya","Kiran","Lakshmi","Manish","Nisha","Om","Pratik","Qadir","Rajesh","Sita","Tara","Umesh","Varun","Wangchuk","Xavier","Yuvraj","Zara"];
const LAST = ["Shrestha","Gurung","Tamang","Magar","Rai","Limbu","Thapa","Karki","Adhikari","Pandey","Bhattarai","Khadka","Pokharel","Sharma","Joshi","Acharya"];
const AREAS = ["Thamel","Patan","Bhaktapur","Kalanki","Boudha","Lazimpat","Baneshwor","Pulchowk","Jawalakhel","Sanepa","Maharajgunj","Kupondole","Kirtipur","Chabahil","Naxal","Tripureshwor"];
const BIZ = ["Grocery Store","Tea Shop","Electronics","Boutique","Pharmacy","Restaurant","Bakery","Stationery","Hardware","Cosmetics","Mobile Shop","Tailor","Cyber Cafe","Bookstore"];

export interface SocialConnection { targetId: string; type: "endorser" | "transaction" | "both"; weight: number; }
export interface MerchantData {
  id: string;
  name: string;
  businessType: string;
  address: string;
  trustScore: number;
  flagged: boolean;
  behavioralData: { timestamp: string; volume: number }[];
  txCategories: { qr: number; p2p: number };
  psychometric: { Discipline: number; Honesty: number; Planning: number; Resilience: number; Consistency: number };
  endorsedBy: { id: string; name: string; rating: number };
  socialConnections: SocialConnection[];
  auditTrail: { date: string; event: string; delta: number }[];
  psychometricAnswers: Record<string, number>;
  calculatedTrustScore: number | null;
}

function seeded(seed: number) {
  let s = seed;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

function genBehavioral(rand: () => number, base: number) {
  const out: { timestamp: string; volume: number }[] = [];
  const now = new Date("2026-05-30");
  let v = base;
  for (let i = 11; i >= 0; i--) {
    const d = new Date(now); d.setMonth(d.getMonth() - i);
    v = Math.max(1000, v + (rand() - 0.45) * base * 0.3);
    out.push({ timestamp: d.toLocaleDateString("en-US", { month: "short", year: "2-digit" }), volume: Math.round(v) });
  }
  return out;
}

export const MERCHANTS: MerchantData[] = Array.from({ length: 100 }, (_, i) => {
  const r = seeded(i + 7);
  const id = `ESW-${String(1001 + i)}`;
  const name = `${FIRST[Math.floor(r() * FIRST.length)]} ${LAST[Math.floor(r() * LAST.length)]}`;
  const businessType = BIZ[Math.floor(r() * BIZ.length)];
  const address = `${AREAS[Math.floor(r() * AREAS.length)]}, Kathmandu`;
  const trustScore = Math.round(500 + r() * 350);
  const base = 20000 + r() * 80000;
  const flagged = i % 33 === 0 || i % 41 === 0;
  return {
    id, name, businessType, address, trustScore, flagged,
    behavioralData: genBehavioral(r, base),
    txCategories: { qr: Math.round(40 + r() * 50), p2p: Math.round(20 + r() * 40) },
    psychometric: {
      Discipline: Math.round(50 + r() * 50),
      Honesty: Math.round(60 + r() * 40),
      Planning: Math.round(40 + r() * 60),
      Resilience: Math.round(50 + r() * 50),
      Consistency: Math.round(45 + r() * 55),
    },
    endorsedBy: { id: `ESW-${1001 + ((i + 13) % 100)}`, name: `${FIRST[Math.floor(r() * FIRST.length)]} ${LAST[Math.floor(r() * LAST.length)]}`, rating: Math.max(3, Math.min(5, Math.round(3 + r() * 2))) },
    socialConnections: Array.from({ length: 4 + Math.floor(r() * 4) }, (_, j) => {
      const t = r();
      return {
        targetId: `ESW-${1001 + ((i + j * 7 + 3) % 100)}`,
        type: t < 0.33 ? "endorser" : t < 0.66 ? "transaction" : "both",
        weight: Math.round(1 + r() * 9),
      } as SocialConnection;
    }),
    auditTrail: Array.from({ length: 5 }, (_, k) => {
      const d = new Date("2026-05-30"); d.setMonth(d.getMonth() - k * 2);
      const delta = Math.round((r() - 0.5) * 40);
      return { date: d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }), event: delta > 0 ? "Positive transaction pattern detected" : delta < 0 ? "Late payment recorded" : "Periodic review", delta };
    }),
    psychometricAnswers: {},
    calculatedTrustScore: null,
  };
});

export const QUIZ_QUESTIONS = [
  { q: "When business revenue unexpectedly surges, what is your immediate reflex?", options: [
    { label: "Reinvest entirely into volatile stock/new trends", score: 2 },
    { label: "Expand core inventory immediately", score: 6 },
    { label: "Save a fixed percentage for emergencies", score: 10 },
    { label: "Pay off outstanding informal debts", score: 8 },
  ]},
  { q: "A key supplier accidentally ships double the inventory you paid for. What happens next?", options: [
    { label: "Keep it and wait to see if they notice", score: 1 },
    { label: "Notify them immediately to arrange return or payment", score: 10 },
    { label: "Use it and pay them during the next order cycle", score: 6 },
  ]},
  { q: "How far in advance are your business expenses planned out?", options: [
    { label: "Day-to-day as needs arise", score: 3 },
    { label: "Week-by-week", score: 6 },
    { label: "Month-by-month with a strict written budget", score: 9 },
    { label: "Year-by-year strategy", score: 10 },
  ]},
  { q: "If a short-term market shift reduces your weekly sales by 30%, how do you manage your upcoming bills?", options: [
    { label: "Take an urgent high-interest loan elsewhere", score: 2 },
    { label: "Rely on a pre-allocated business cash buffer", score: 10 },
    { label: "Delay payments to suppliers without warning", score: 3 },
  ]},
  { q: "Which business philosophy describes you best?", options: [
    { label: "'High risk, massive returns instantly'", score: 3 },
    { label: "'Steady, highly predictable, disciplined growth'", score: 10 },
    { label: "'Adapting organically without fixed long-term planning'", score: 6 },
  ]},
  { q: "How often do you reconcile your daily sales with your bank/eSewa balance?", options: [
    { label: "Every single day", score: 10 },
    { label: "A few times a week", score: 7 },
    { label: "Only when something feels off", score: 3 },
  ]},
  { q: "A customer overpays by Rs. 500. What's your move?", options: [
    { label: "Refund immediately via eSewa", score: 10 },
    { label: "Note it and refund on their next visit", score: 7 },
    { label: "Keep it — they probably won't return", score: 1 },
  ]},
  { q: "What portion of profit do you typically reinvest vs. save?", options: [
    { label: "100% reinvest, 0% save", score: 3 },
    { label: "70% reinvest, 30% save", score: 8 },
    { label: "50/50 split", score: 10 },
    { label: "Mostly save, minimal reinvestment", score: 6 },
  ]},
  { q: "How do you treat informal loans from family or friends?", options: [
    { label: "Same as any formal debt — strict repayment schedule", score: 10 },
    { label: "Repay when business allows", score: 5 },
    { label: "Only repay if they ask", score: 2 },
  ]},
  { q: "Your trusted neighbor merchant asks you to endorse them. They're a moderate risk. You:", options: [
    { label: "Endorse fully — relationships matter", score: 4 },
    { label: "Politely decline — your reputation matters more", score: 9 },
    { label: "Endorse with a written caveat about the risk", score: 10 },
  ]},
];