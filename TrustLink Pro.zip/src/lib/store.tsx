import { createContext, useContext, useState, type ReactNode } from "react";
import { MERCHANTS, type MerchantData } from "./mockData";

type Role = "admin" | "merchant" | null;

interface AppState {
  role: Role;
  currentUser: MerchantData | null;
  merchants: MerchantData[];
  selectedMerchantId: string | null;
  login: (email: string) => Role;
  logout: () => void;
  selectMerchant: (id: string | null) => void;
  setQuizAnswers: (answers: Record<string, number>) => void;
  setCalculatedScore: (id: string, score: number) => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>(null);
  const [merchants, setMerchants] = useState<MerchantData[]>(MERCHANTS);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [selectedMerchantId, setSelectedMerchantId] = useState<string | null>(null);

  const login = (email: string): Role => {
    if (email.trim().toLowerCase() === "admin@esewa.com") {
      setRole("admin");
      return "admin";
    }
    setRole("merchant");
    setCurrentUserId(merchants[0].id);
    return "merchant";
  };

  const currentUser = merchants.find((m) => m.id === currentUserId) ?? null;

  return (
    <Ctx.Provider
      value={{
        role,
        currentUser,
        merchants,
        selectedMerchantId,
        login,
        logout: () => { setRole(null); setCurrentUserId(null); setSelectedMerchantId(null); },
        selectMerchant: setSelectedMerchantId,
        setQuizAnswers: (answers) => {
          if (!currentUserId) return;
          setMerchants((prev) => prev.map((m) => m.id === currentUserId ? { ...m, psychometricAnswers: answers } : m));
        },
        setCalculatedScore: (id, score) => {
          setMerchants((prev) => prev.map((m) => m.id === id ? { ...m, calculatedTrustScore: score } : m));
        },
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}