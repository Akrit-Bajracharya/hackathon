import { useEffect, useState } from "react";

export function TrustGauge({ score, size = 240, label = "Trust Score" }: { score: number; size?: number; label?: string }) {
  const [display, setDisplay] = useState(0);
  useEffect(() => {
    const start = performance.now();
    const dur = 1200;
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(score * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [score]);

  const r = size / 2 - 16;
  const c = 2 * Math.PI * r;
  const pct = Math.min(1, Math.max(0, (score - 300) / 600));
  const offset = c * (1 - pct);
  const color = score >= 750 ? "oklch(0.68 0.18 142)" : score >= 600 ? "oklch(0.75 0.15 90)" : "oklch(0.65 0.2 30)";
  const tier = score >= 750 ? "Excellent" : score >= 650 ? "Strong" : score >= 550 ? "Fair" : "Building";

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90 absolute inset-0">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="oklch(0.94 0.01 240)" strokeWidth={14} />
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none" stroke={color} strokeWidth={14} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1.2s cubic-bezier(.2,.8,.2,1)" }}
        />
      </svg>
      <div className="relative flex flex-col items-center pointer-events-none">
        <div className="text-5xl font-bold text-foreground tabular-nums">{display}</div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">{label}</div>
        <div className="mt-2 px-3 py-0.5 rounded-full text-xs font-semibold" style={{ backgroundColor: color + "20", color }}>{tier}</div>
      </div>
    </div>
  );
}