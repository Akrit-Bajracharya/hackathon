import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { ShieldCheck, LogOut, LayoutDashboard, User, Brain, Share2 } from "lucide-react";
import { useApp } from "@/lib/store";
import type { ReactNode } from "react";

export function AppShell({ children }: { children: ReactNode }) {
  const { role, currentUser, logout } = useApp();
  const nav = useNavigate();
  const path = useRouterState({ select: (r) => r.location.pathname });

  const links = role === "admin"
    ? [{ to: "/admin", label: "Admin Dashboard", icon: LayoutDashboard }]
    : [
        { to: "/merchant", label: "My Profile", icon: User },
        { to: "/quiz", label: "Psychometric", icon: Brain },
        { to: "/network", label: "My Network", icon: Share2 },
      ];

  return (
    <div className="min-h-screen bg-[oklch(0.985_0.005_240)]">
      <header className="sticky top-0 z-40 bg-card/80 backdrop-blur-xl border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 h-16 flex items-center justify-between gap-6">
          <Link to={role === "admin" ? "/admin" : "/merchant"} className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-lg bg-primary flex items-center justify-center shadow-md shadow-primary/30">
              <ShieldCheck className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="leading-tight">
              <div className="text-sm font-bold text-foreground">eSewa Trust</div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{role === "admin" ? "Admin Console" : "Merchant Portal"}</div>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {links.map((l) => {
              const active = path === l.to;
              const Icon = l.icon;
              return (
                <Link key={l.to} to={l.to}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition ${active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}>
                  <Icon className="h-4 w-4" />{l.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right leading-tight">
              <div className="text-xs font-semibold text-foreground">{role === "admin" ? "Loan Officer" : currentUser?.name}</div>
              <div className="text-[10px] text-muted-foreground">{role === "admin" ? "admin@esewa.com" : currentUser?.id}</div>
            </div>
            <button onClick={() => { logout(); nav({ to: "/" }); }}
              className="h-9 w-9 rounded-lg border border-border hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>
      <main className="max-w-[1400px] mx-auto px-6 py-6">{children}</main>
    </div>
  );
}